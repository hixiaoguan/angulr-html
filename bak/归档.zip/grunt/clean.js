module.exports = {
  html: ['html/*'],
  tmp: ['.tmp']
};
