module.exports = {
  html: ['src/index.html'],
  options: {
    dest: 'html'
  }
}
